﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laberinto
{
    public partial class Form1 : Form
    {
        private Label[,] mat;
        private bool salida;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int x = 10;
            int y = 50;
            mat = new Label[10, 10];
            for (int fil = 0; fil < mat.GetLength(0); fil++)
            {
                for (int col = 0; col < mat.GetLength(1); col++)
                {
                    mat[fil, col] = new Label();
                    mat[fil, col].Location = new Point(x, y);
                    mat[fil, col].Size = new Size(30, 30);
                    Controls.Add(mat[fil, col]);
                    x = x + 32;
                }
                y = y + 32;
                x = 10;
            }
            Crear();
        }

        private void Crear()
        {
            Text = "";
            button1.Enabled = true;
            Random ale = new Random();
            for (int f = 0; f < 10; f++)
            {
                for (int c = 0; c < 10; c++)
                {
                    mat[f, c].BackColor = Color.Azure;
                    int a = ale.Next(0, 4);
                    if (a == 0)
                        mat[f, c].Text = "1";
                    else
                        mat[f, c].Text = "0"; ;
                }
            }
            mat[9, 9].Text = "s";
            mat[0, 0].Text = "0";
        }

        private void Recorrer(int fil, int col)
        {
            if (fil >= 0 && fil < 10 && col >= 0 && col < 10 && salida == false)
            {
                if (mat[fil, col].Text == "s")
                    salida = true;
                else
                    if (mat[fil, col].Text == "0")
                {
                    mat[fil, col].Text = "9";
                    mat[fil, col].BackColor = Color.Red;
                    Recorrer(fil, col + 1);
                    Recorrer(fil + 1, col);
                    Recorrer(fil - 1, col);
                    Recorrer(fil, col - 1);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            salida = false;
            Recorrer(0, 0);
            if (salida == true)
                Text = "Tiene salida";
            else
                Text = "No tiene salida";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Crear();
        }
    }
}